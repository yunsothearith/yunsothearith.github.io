<!DOCTYPE html>
	<html lang="en-US">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Alex Smith &#8212; WordPress</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel='stylesheet' id='dashicons-css'  href='https://lmpixels.com/wp/aveo/wp-includes/css/dashicons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='https://lmpixels.com/wp/aveo/wp-includes/css/buttons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='https://lmpixels.com/wp/aveo/wp-admin/css/forms.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='https://lmpixels.com/wp/aveo/wp-admin/css/l10n.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='https://lmpixels.com/wp/aveo/wp-admin/css/login.min.css' type='text/css' media='all' />
<script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//lmpixels.com/wp/aveo/?wordfence_lh=1&hid=510A5F11A668D9CF750070FE6AC9A4C9');
</script>	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		<script async src='/cdn-cgi/challenge-platform/h/g/scripts/invisible.js'></script></head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-us">
	<script type="text/javascript">
		document.body.className = document.body.className.replace('no-js','js');
	</script>
		<div id="login">
		<h1><a href="https://wordpress.org/">Powered by WordPress</a></h1>
	
		<form name="loginform" id="loginform" action="https://lmpixels.com/wp/aveo/wp-login.php" method="post">
			<p>
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Password</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Remember Me</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
									<input type="hidden" name="redirect_to" value="https://lmpixels.com/wp/aveo/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
								<a href="https://lmpixels.com/wp/aveo/wp-login.php?action=lostpassword">Lost your password?</a>
			</p>
					<script type="text/javascript">
			function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }		</script>
				<p id="backtoblog">
			<a href="https://lmpixels.com/wp/aveo/">&larr; Go to Alex Smith</a>		</p>
			</div>
	<script type='text/javascript' id='js-0-js-extra'>
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/lmpixels.com\/wp\/aveo\/wp-includes\/js\/zxcvbn.min.js"};var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};var _wpUtilSettings = {"ajax":{"url":"\/wp\/aveo\/wp-admin\/admin-ajax.php"}};var userProfileL10n = {"user_id":"0","nonce":"5add7070f9"};
/* ]]> */
</script>
<script type='text/javascript' src='https://lmpixels.com/wp/aveo/wp-content/mmr/761940c5-1627553433.min.js' id='js-0-js'></script>
	<div class="clear"></div>
	<script type="text/javascript">(function(){window['__CF$cv$params']={r:'68aec33889064fdc',m:'uA7s9I.gWNgcccWkkIp50vXjOtQSr9qC0Fjx10Fgs10-1631005393-0-ARCWFRd2xJMbsuXaPUwNV9sirneTtj1Qetkd3x631NINLg5cuGYTmFyrdKR8GE596s00Hg86Jhl6sxyseC3gSiwA+XTPSRlrE2B9Rnrgw+mLbBuuI5k/MKfNqFGYohttQARSgdcLzygbKVSg4OlTuAg=',s:[0x8a4ed4c5a3,0xc3eddc8f29],u:'/cdn-cgi/challenge-platform/h/g'}})();</script><script defer src="https://static.cloudflareinsights.com/beacon.min.js" data-cf-beacon='{"rayId":"68aec33889064fdc","version":"2021.8.1","r":1,"token":"94b99c0576dc45bf9d669fb5e9256829","si":10}'></script>
</body>
	</html>
	